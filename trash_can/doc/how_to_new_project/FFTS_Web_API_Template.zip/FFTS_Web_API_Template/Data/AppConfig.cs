﻿using System.Collections.Generic;

namespace FFTS.IOptions
{
    public class AppConfig
    {
        public string APP_ID { get; set; }
    }
}
