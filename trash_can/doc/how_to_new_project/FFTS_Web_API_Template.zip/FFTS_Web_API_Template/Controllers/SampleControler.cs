﻿using FFTS.InternalCommonHttpClients;
using FFTS.IOptions;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

using System.Net.Http;

namespace $safeprojectname$
{
    [Route("api/[controller]")]
    [ApiController]
    public class SampleControler : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly AppConfig _appConfig;
        private readonly HttpClient _inHttpClient;

        public SampleControler(IConfiguration config, IOptions<AppConfig> appConfig, AnyInternalApiClient inApiClient)
        {
            _config = config;
            _appConfig = appConfig.Value;
            _inHttpClient = inApiClient.HttpClient;
        }

        [HttpGet]
        public object SampleAction()
        {
            var value = "I am value";
            return new { key = value };
        }
    }
}
