using FFTS.InternalCommonHttpClients;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IConfiguration _configuration;
        private readonly IHostApplicationLifetime _lifetime;
        private readonly HttpClient _httpClient;

        public Worker(ILogger<Worker> logger, IConfiguration configuration, IHostApplicationLifetime lifetime, AnyInternalApiClient inApiClient)
        {
            _logger = logger;
            _configuration = configuration;
            _lifetime = lifetime;
            _httpClient = inApiClient.HttpClient;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Start ExecuteAsync");
            try
            {
                // do something
                await Task.Delay(2000);
                _logger.LogInformation("do something");

                Environment.ExitCode = ((int)ExitCode.SUCCESS);
                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Job fail: {ex.Message}");
                Environment.ExitCode = ((int)ExitCode.FAIL);
            }
            finally
            {
                _logger.LogInformation("Stop Application");
                _lifetime.StopApplication();
            }
        }

        enum ExitCode
        {
            // zero means success, any num greater zero is error
            SUCCESS = 0,
            FAIL = 1
        }

    }
}
